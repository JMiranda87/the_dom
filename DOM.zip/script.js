function hide(element) {
    element.remove();
}

function addLikesTop() {
    var element = document.getElementById('top');
    var value = element.innerHTML;

    ++value;

    console.log(value);
    document.getElementById('top').innerHTML = value;
}

function addLikesMiddle() {
    var element = document.getElementById('middle');
    var value = element.innerHTML;

    ++value;

    console.log(value);
    document.getElementById('middle').innerHTML = value;
}

function addLikesBottom() {
    var element = document.getElementById('bottom');
    var value = element.innerHTML;

    ++value;

    console.log(value);
    document.getElementById('bottom').innerHTML = value;
}